# ML-algorithms-implementation-from-scratch
The motivation behind these projects was to apply an understanding of the algorithms and to use the simple dataset for them. The main objective was not to use any machine learning library. The modelling was carried out in the lines of Andrew Ng’s ML course on Coursera and using NumPy. Further, it was done using scikit-learn too.


